#ifndef STRING_HELPER_H_2006_03_28
#define STRING_HELPER_H_2006_03_28

#include <cassert>
#include <typeinfo>
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <functional>
#include <exception>

/** @namespace StringHelper
 *  @brief Collection of functions for processing strings.
 *
 *  The namespace consists of functions for processing strings. <br>
 *  Most of these functions is applicable to both std::string and std::wstring. <br>
 *  The range definition is consistent with STL, i.e. [Begin, End) .
 *
 *  @author Huang Yun, huangyunict@gmail.com
 *  @date 2006-11-07
 *
 */
namespace StringHelper
{

typedef std::string::size_type size_type;   /**< typedef size_type. */

/** @name Stream Functions 
 *
 *  Functions in this group provides abstract functions of cin/wcin, cout/wcout, cerr/wcerr, clog/wclog.
 *
 */ 
/** @{ */
/** @brief Abstract of cin/wcin.
 *
 *  @return Return the abstract of cin/wcin.
 */
template <class _CharType>
std::basic_istream<_CharType>& Cin();

/** @brief Abstract of cout/wcout.
 *
 *  @return Return the abstract of cout/wcout.
 */
template <class _CharType>
std::basic_ostream<_CharType>& Cout();

/** @brief Abstract of cerr/wcerr.
 *
 *  @return Return the abstract of cerr/wcerr.
 */
template <class _CharType>
std::basic_ostream<_CharType>& Cerr();

/** @brief Abstract of clog/wclog.
 *
 *  @return Return the abstract of clog/wclog.
 */
template <class _CharType>
std::basic_ostream<_CharType>& Clog();
/** @} */


/** @name CConv/Widen/Narrow Functions 
 *
 *  Functions in this group convert between char and wchar_t.
 *  @note Only available for ASCII characters or strings. <br>
 *        If narrow failed to convert, return '\\0'.
 */
/** @{ */
/** @brief Convert between C++ type char and C++ type wchar_t.
 *
 *  @param[in] __Char The input character.
 *  @return Return the converted character.
 *  @note If failed to convert, return '\\0'.
 */
template <class _OutputCharType, class _InputCharType>
_OutputCharType CConv(_InputCharType __Char);

/** @brief Convert between std::string and std::wstring.
 *
 *  @param[in] __String The input string or wstring.
 *  @return Return the converted string or wstring.
 */
template <class _OutputCharType, class _InputCharType>
std::basic_string<_OutputCharType> CConv(const std::basic_string<_InputCharType>& __String);

/** @brief Widen C++ type char to given output type.
 *
 *  @param[in] __Char The input character.
 *  @return Return the converted character.
 */
template <class _CharType>
_CharType Widen(char __Char);

/** @brief Widen C-style string to std::basic_string of given type.
 *
 *  @param[in] __String The input string.
 *  @return Return the converted string.
 */
template <class _CharType>
std::basic_string<_CharType> Widen(const char* __String);

/** @brief Widen std::string to std::basic_string of given type.
 *
 *  @param[in] __String The input string.
 *  @return Return the converted string.
 */
template <class _CharType>
std::basic_string<_CharType> Widen(const std::string& __String);

/** @brief Narrow C++ type wchar_t to given output type.
 *
 *  @param[in] __Char The input character.
 *  @return Return the converted character.
 */
template <class _CharType>
_CharType Narrow(wchar_t __Char);

/** @brief Narrow C-style wstring to std::basic_string of given type.
 *
 *  @param[in] __String The input string.
 *  @return Return the converted string.
 */
template <class _CharType>
std::basic_string<_CharType> Narrow(const wchar_t* __String);

/** @brief Narrow std::wstring to std::basic_string of given type.
 *
 *  @param[in] __String The input string.
 *  @return Return the converted string.
 */
template <class _CharType>
std::basic_string<_CharType> Narrow(const std::wstring& __String);
/** @} */


/** @name Convert Functions 
 *
 *  Functions in this group convert between string and other types.
 *  @note These function do not check whether actually converted.
 */
/** @{ */
/** @brief Convert string to other type.
 *
 *  @param[in] __String The input string.
 *  @return Return converted value of other type.
 */
template <class _CharType, class _OtherType>
_OtherType String2Other(const std::basic_string<_CharType>& __String);

//template <>
//inline std::basic_string<char> String2Other<char, std::basic_string<char> >(const std::basic_string<char>& __String);
//
//template <>
//inline std::basic_string<wchar_t> String2Other<wchar_t, std::basic_string<wchar_t> >(const std::basic_string<wchar_t>& __String);

/** @brief Convert other type to string.
 *
 *  @param[in] __Other The input value of other type.
 *  @return Return converted string.
 *  @note If input is a string, return the input, do NOT use string stream, i.e. spaces are kept.
 */
template <class _CharType, class _OtherType>
std::basic_string<_CharType> Other2String(const _OtherType& __Other);
/** @} */


/** @name Concatenate/Split Functions 
 *
 *  Functions in this group concatenate multiple item to string, or split string into multiple items.
 */
/** @{ */
/** @brief Concatenate every item in range to string, separated by given separator. 
 *
 *  @param[in] __Begin The begin iterator.
 *  @param[in] __End The end iterator.
 *  @param[in] __Separator The separator string written between two items.
 *  @return Return the concatenated string.
 */
template <class _CharType, class _InputIter>
std::basic_string<_CharType> Concat(_InputIter __Begin, _InputIter __End, const std::basic_string<_CharType>& __Separator = Widen<_CharType>(" "));

/** @brief Split items from stream separated by spaces.
 *
 *  The items of given element type are separated by space characters, and output to iterator.
 *
 *  @param[in] __Stream The input stream.
 *  @param[in] __Result The output iterator.
 *  @return Return the output iterator pointed to next output position.
 */
template <class _CharType, class _ElemType, class _OutputIter>
_OutputIter SplitSpace(std::basic_istream<_CharType>& __Stream, _OutputIter __Result);

/** @brief Split items from string separated by spaces.
 *
 *  The items of given element type are separated by space characters, and output to iterator.
 *  @param[in] __String The input string.
 *  @param[in] __Result The output iterator.
 *  @return Return the output iterator pointed to next output position.
 */
template <class _CharType, class _ElemType, class _OutputIter>
_OutputIter SplitSpace(const std::basic_string<_CharType>& __String, _OutputIter __Result);

/** @brief Split strings from stream separated by spaces.
 *
 *  The strings are separated by space characters, and output to iterator.
 *
 *  @param[in] __Stream The input stream.
 *  @param[in] __Result The output iterator.
 *  @return Return the output iterator pointed to next output position.
 */
template <class _CharType, class _OutputIter>
_OutputIter SplitSpace(std::basic_istream<_CharType>& __Stream, _OutputIter __Result);

/** @brief Split items from string separated by spaces.
 *
 *  The strings are separated by space characters, and output to iterator.
 *  @param[in] __String The input string.
 *  @param[in] __Result The output iterator.
 *  @return Return the output iterator pointed to next output position.
 */
template <class _CharType, class _OutputIter>
_OutputIter SplitSpace(const std::basic_string<_CharType>& __String, _OutputIter __Result);

/** @brief Split items from string separated by given character.
 *
 *  @param[in] __String The input string.
 *  @param[in] __Result The output iterator.
 *  @param[in] __Separator The separating character.
 *  @param[in] __OutputEmpty Whether to output, if there is nothing between two adjacent separators.
 *  @return Return the output iterator pointed to next output position.
 */
template <class _CharType, class _ElemType, class _OutputIter>
_OutputIter SplitChar(const std::basic_string<_CharType>& __String, _OutputIter __Result, _CharType __Separator = Widen<_CharType>(' '), bool __OutputEmpty = false);

/** @brief Split items from string separated by given string.
 *
 *  @param[in] __String The input string.
 *  @param[in] __Result The output iterator.
 *  @param[in] __Separator The separating string.
 *  @param[in] __OutputEmpty Whether to output, if there is nothing between two adjacent separators.
 *  @return Return the output iterator pointed to next output position.
 */
template <class _CharType, class _ElemType, class _OutputIter>
_OutputIter SplitString(const std::basic_string<_CharType>& __String, _OutputIter __Result, const std::basic_string<_CharType>& __Separator = Widen<_CharType>(" "), bool __OutputEmpty = false);

/** @brief Split Chinese characters from string.
 *
 *  @param[in] __String The input string.
 *  @param[in] __Result The output iterator.
 *  @return Return the output iterator pointed to next output position.
 *  @note Chinese character is two bytes, one byte followed by negative char.
 *  @exception Throw error message.
 */
template <class _OutputIter>
_OutputIter SplitGB(const std::string& __String, _OutputIter __Result) throw (std::string);
/** @} */


/** @name Case change Functions 
 *
 *  Functions in this group could change the lower/upper case of char or string.
 *  @note If change std::string, do NOT change the byte following negative byte. <br>
 *        If change std::wstring, do NOT check whether negative.
 */
/** @{ */
/** @brief Change case of single character.
 *
 *  @param[in] __Char The character.
 *  @param[in] __U2L  If true, convert from upper to lower, otherwise from lower to upper. 
 *  @return If converted, return the converted character, otherwise return the input character. 
 */
template <class _CharType>
static _CharType ChangeCase(_CharType __Char, bool __U2L);

/** @brief Change case of range.
 *
 *  @param[in] __Begin The begin iterator.
 *  @param[in] __End   The end iterator.
 *  @param[in] __U2L  If true, convert from upper to lower, otherwise from lower to upper. 
 */
template <class _CharType, class _ForwardIter>
static void ChangeCase(_ForwardIter __Begin, _ForwardIter __End, bool __U2L);

/** @brief Convert single character to lower case.
 *
 *  @param[in]  __Char The character.
 *  @return If converted, return the converted character, otherwise return the input   character.
 */
template <class _CharType>
_CharType ToLower(_CharType __Char);

/** @brief Convert range to lower case.
 *
 *  @param[in] __Begin The begin iterator.
 *  @param[in] __End   The end iterator.
 */
template <class _CharType, class _ForwardIter>
void ToLower(_ForwardIter __Begin, _ForwardIter __End);

/** @brief Convert string to lower case.
 *
 *  @param[in]  __String The input string.
 *  @param[out] __String The output string.
 */
template <class _CharType>
void ToLower(std::basic_string<_CharType>& __String);

/** @brief Convert single character to upper case.
 *
 *  @param[in]  __Char The character.
 *  @return If converted, return the converted character, otherwise return the input   character.
 */
template <class _CharType>
_CharType ToUpper(_CharType __Char);

/** @brief Convert range to upper case.
 *
 *  @param[in] __Begin The begin iterator.
 *  @param[in] __End   The end iterator.
 */
template <class _CharType, class _ForwardIter>
void ToUpper(_ForwardIter __Begin, _ForwardIter __End);

/** @brief Convert string to upper case.
 *
 *  @param[in]  __String The input string.
 *  @param[out] __String The output string.
 */
template <class _CharType>
void ToUpper(std::basic_string<_CharType>& __String);
/** @} */

/** @name Trim Functions 
 *
 *  Functions in this group could trim left/right characters of string.
 */
/** @{ */
/** @brief Trim all given characters in left of string.
 *
 *  @param[in]  __String The input string.
 *  @param[in]  __Trim   The character set to trim.
 *  @param[out] __String The output string after trimming.
 *  @return Return the reference of trimmed string.
 */
template <class _CharType>
std::basic_string<_CharType>& TrimLeft(std::basic_string<_CharType>& __String, const std::basic_string<_CharType>& __Trim = Widen<_CharType>(std::string(" \r\n\t")));

/** @brief Trim all given characters in right of string.
 *
 *  @param[in]  __String The input string.
 *  @param[in]  __Trim   The character set to trim.
 *  @param[out] __String The output string after trimming.
 *  @return Return the reference of trimmed string.
 */
template <class _CharType>
std::basic_string<_CharType>& TrimRight(std::basic_string<_CharType>& __String, const std::basic_string<_CharType>& __Trim = Widen<_CharType>(std::string(" \r\n\t")));

/** @brief Trim all given characters in both left and right of string.
 *
 *  @param[in]  __String The input string.
 *  @param[in]  __Trim   The character set to trim.
 *  @param[out] __String The output string after trimming.
 *  @return Return the reference of trimmed string.
 */
template <class _CharType>
std::basic_string<_CharType>& Trim(std::basic_string<_CharType>& __String, const std::basic_string<_CharType>& __Trim = Widen<_CharType>(std::string(" \r\n\t")));
/** @} */


/** @name Miscellaneous Functions
 *
 *  Miscellaneous functions.
 */
/** @{ */
/** @brief Replace old sub string to new sub string.
 *
 *  @param[in]  __String The input string.
 *  @param[in]  __Old The old sub string.
 *  @param[in]  __New The new sub string.
 *  @return Return replaced string.
 */
template <class _CharType>
std::basic_string<_CharType> Replace(const std::basic_string<_CharType>& __String, const std::basic_string<_CharType>& __Old, const std::basic_string<_CharType>& __New);

/** @brief Get content between the begin and end XML tags.
 *
 *  @param[in]  __String The input string.
 *  @param[in]  __Tag The XML tag.
 *  @return Return the content between the begin and end XML tags. 
 *  @note Get content from "<foo id="1"\>bar</foo\>" given tag "foo" will be "bar".
 *  @exception If format error, throw error message. 
 */
template <class _CharType>
std::basic_string<_CharType> XMLContent(const std::basic_string<_CharType>& __String, const std::basic_string<_CharType>& __Tag) throw (std::basic_string<_CharType>);

/** @brief Get the value of given attribute.
 *
 *  @param[in]  __String    The input string.
 *  @param[in]  __Tag       The XML tag.
 *  @param[in]  __Attribute The given attribute name.
 *  @return Return the value of given attribute. 
 *  @note Get value from "<foo id="1"\>bar</foo\>" given tag "foo" and attribute "id" will be "1".
 *  @exception If format error, throw error message. 
 */
template <class _CharType>
std::basic_string<_CharType> XMLAttribute(const std::basic_string<_CharType>& __String, const std::basic_string<_CharType>& __Tag, const std::basic_string<_CharType>& __Attribute) throw (std::basic_string<_CharType>);
/** @} */

};  //  namespace StringHelper

////////////////////////////////////////////////////////////////////////////////
//  implementation

namespace StringHelper
{

template <>
inline std::basic_istream<char>& Cin()
{
    return std::cin;
}

template <>
inline std::basic_istream<wchar_t>& Cin()
{
    return std::wcin;
}

template <>
inline std::basic_ostream<char>& Cout()
{
    return std::cout;
}

template <>
inline std::basic_ostream<wchar_t>& Cout()
{
    return std::wcout;
}

template <>
inline std::basic_ostream<char>& Cerr()
{
    return std::cerr;
}

template <>
inline std::basic_ostream<wchar_t>& Cerr()
{
    return std::wcerr;
}

template <>
inline std::basic_ostream<char>& Clog()
{
    return std::clog;
}

template <>
inline std::basic_ostream<wchar_t>& Clog()
{
    return std::wclog;
}

/** @brief Instantiate CConv.
 */
template <>
inline char CConv<char, char>(char __Char)
{
    return __Char;
}

/** @brief Instantiate CConv.
 */
template <>
inline wchar_t CConv<wchar_t, char>(char __Char)
{
    return std::wcout.widen(__Char);
}

/** @brief Instantiate CConv.
 */
template <>
inline char CConv<char, wchar_t>(wchar_t __Char)
{
    return std::cout.narrow(__Char, '\0');
}

/** @brief Instantiate CConv.
 */
template <>
inline wchar_t CConv<wchar_t, wchar_t>(wchar_t __Char)
{
    return __Char;
}

/** @brief Instantiate CConv.
 */
template <>
inline std::basic_string<char> CConv<char, char>(const std::string& __String)
{
    return __String;
}

/** @brief Instantiate CConv.
 */
template <>
inline std::basic_string<wchar_t> CConv<wchar_t, char>(const std::string& __String)
{
    std::basic_string<wchar_t> ws;
    ws.resize(__String.length());
    for (size_type i=0; i<__String.length(); ++i)
    {
        ws[i] = CConv<wchar_t>(__String[i]);
    }
    return ws;
}

/** @brief Instantiate CConv.
 */
template <>
inline std::basic_string<char> CConv<char, wchar_t>(const std::wstring& __String)
{
    std::basic_string<char> s;
    s.resize(__String.length());
    for (size_type i=0; i<__String.length(); ++i)
    {
        s[i] = CConv<char>(__String[i]);
    }
    return s;
}

/** @brief Instantiate CConv.
 */
template <>
inline std::basic_string<wchar_t> CConv<wchar_t, wchar_t>(const std::wstring& __String)
{
    return __String;
}

template <class _CharType>
inline _CharType Widen(char __Char)
{
    return CConv<_CharType>(__Char);
}

template <class _CharType>
inline std::basic_string<_CharType> Widen(const char* __String)
{
    return Widen<_CharType>(std::string(__String));
}

template <class _CharType>
std::basic_string<_CharType> Widen(const std::string& __String)
{
    return CConv<_CharType>(__String);
}

template <class _CharType>
inline _CharType Narrow(wchar_t __Char)
{
    return CConv<_CharType>(__Char);
}

template <class _CharType>
inline std::basic_string<_CharType> Narrow(const wchar_t* __String)
{
    return Narrow<_CharType>(std::string(__String));
}

template <class _CharType>
inline std::basic_string<_CharType> Narrow(const std::wstring& __String)
{
    return CConv<_CharType>(__String);
}

template <class _CharType, class _InputIter>
std::basic_string<_CharType> Concat(_InputIter __Begin, _InputIter __End, const std::basic_string<_CharType>& __Separator)
{
    std::basic_ostringstream<_CharType> oss;
    bool first = true;
    for (; __Begin!=__End; ++__Begin)
    {
        if (first)
        {
            first = false;
        }
        else
        {
            oss << __Separator;
        }
        oss << *__Begin;
    }
    return oss.str();
}

template <class _CharType>
inline _CharType ChangeCase(_CharType __Char, bool __U2L)
{
    _CharType srcb, srce, tgtb;
    //  set variables
    if (__U2L)
    {
        srcb = _CharType('A');
        tgtb = _CharType('a');
    }
    else
    {
        srcb = _CharType('a');
        tgtb = _CharType('A');
    }
    srce = srcb + ('Z' - 'A');
    //  change case 
    if (__Char >= srcb && __Char <= srce)
    {
        __Char = __Char - srcb + tgtb;
    }
    return __Char;
}

template <class _CharType, class _ForwardIter>
void ChangeCase(_ForwardIter __Begin, _ForwardIter __End, bool __U2L)
{
    bool charflag;
    if (typeid(_CharType) == typeid(char))
    {
        charflag = true;
    }
    else
    {
        charflag = false;
    }
    bool flag = false;  //  only used in string
    for (; __Begin!=__End; ++__Begin)
    {
        if (charflag && flag)
        {
            flag = false;
        }
        else if (charflag && *__Begin < 0)
        {
            flag = true;
        }
        else
        {
            _CharType c = static_cast<_CharType>(*__Begin);
            *__Begin = ChangeCase<_CharType>(c, __U2L);
        }
    }
}

template <class _CharType, class _OtherType>
inline std::basic_string<_CharType> Other2String(const _OtherType& __Other)
{
    std::basic_ostringstream<_CharType> oss;
    oss << __Other;
    return oss.str();
}

template <class _CharType, class _OtherType>
inline _OtherType String2Other(const std::basic_string<_CharType>& __String)
{
    //std::cerr<<"in general String2Other: _CharType="<<typeid(_CharType).name()<<" _OtherType="<<typeid(_OtherType).name()<<std::endl;
    assert(typeid(_OtherType) != typeid(std::string));
    assert(typeid(_OtherType) != typeid(std::wstring));
    std::basic_istringstream<_CharType> iss(__String);
    _OtherType o;
    iss >> o;
    return o;
}

template <>
inline std::string String2Other<char, std::string>(const std::string& __String)
{
    //std::cerr<<"in char String2Other"<<std::endl;
    return __String;
}

template <>
inline std::wstring String2Other<wchar_t, std::wstring>(const std::wstring& __String)
{
    //std::cerr<<"in wchar_t String2Other"<<std::endl;
    return __String;
}

template <class _CharType>
std::basic_string<_CharType> Replace(const std::basic_string<_CharType>& __String, const std::basic_string<_CharType>& __Old, const std::basic_string<_CharType>& __New)
{
    if (__Old.empty())
    {
        return __String;
    }
    std::basic_string<_CharType> s;
    size_type prevpos = 0, pos;
    while (true)
    {
        pos = __String.find(__Old, prevpos);
        if (pos == std::basic_string<_CharType>::npos)
        {
            pos = __String.length();
        }
        s.insert(s.length(), __String, prevpos, pos - prevpos);
        if (pos == __String.length())
        {
            break;
        }
        s.insert(s.length(), __New);
        prevpos = pos + __Old.length();
    }
    return s;
}

template <class _CharType, class _ElemType, class _OutputIter>
_OutputIter SplitSpace(std::basic_istream<_CharType>& __Stream, _OutputIter __Result)
{
    _ElemType elem;
    while (__Stream >> elem)
    {
        *__Result = elem;
        ++__Result;
    }
    return __Result;
}

template <class _CharType, class _ElemType, class _OutputIter>
inline _OutputIter SplitSpace(const std::basic_string<_CharType>& __String, _OutputIter __Result)
{
    std::basic_istringstream<_CharType> iss;
    iss.str(__String);
    return SplitSpace<_CharType, _ElemType, _OutputIter>(iss, __Result);
}

template <class _CharType, class _OutputIter>
inline _OutputIter SplitSpace(std::basic_istream<_CharType>& __Stream, _OutputIter __Result)
{
    return SplitSpace<_CharType, std::basic_string<_CharType>, _OutputIter>(__Stream, __Result);
}

template <class _CharType, class _OutputIter>
inline _OutputIter SplitSpace(const std::basic_string<_CharType>& __String, _OutputIter __Result)
{
    return SplitSpace<_CharType, std::basic_string<_CharType>, _OutputIter>(__String, __Result);
}

template <class _CharType, class _ElemType, class _OutputIter>
inline _OutputIter SplitChar(const std::basic_string<_CharType>& __String, _OutputIter __Result, _CharType __Separator, bool __OutputEmpty)
{
    std::basic_string<_CharType> s;
    s += __Separator;
    return SplitString<_CharType, _ElemType, _OutputIter>(__String, __Result, s, __OutputEmpty);
}

template <class _CharType, class _ElemType, class _OutputIter>
_OutputIter SplitString(const std::basic_string<_CharType>& __String, _OutputIter __Result, const std::basic_string<_CharType>& __Separator, bool __OutputEmpty)
{
    size_type pos1 = 0;
    size_type pos2 = 0;
    if (__String.empty() || __Separator.empty())
    {
        return __Result;
    }
    while (true)
    {
        pos2 = __String.find(__Separator, pos1);
        if (pos2 == std::basic_string<_CharType>::npos)
        {
            pos2 = __String.length();
        }
        if (pos2 != pos1 || __OutputEmpty)
        {
            *__Result = String2Other<_CharType, _ElemType>(__String.substr(pos1, pos2 - pos1));
            ++__Result;
        }
        pos1 = pos2 + __Separator.length();
        if (pos2 == __String.length())
        {
            break;
        }
    }
    return __Result;
}

template <class _OutputIter>
_OutputIter SplitGB(const std::string& __String, _OutputIter __Result) throw (std::string)
{
    bool flag = false;
    std::string word;
    for (size_type i=0; i<__String.size(); ++i)
    {
        char c = __String[i];
        if (flag)
        {
            word += c;
            *__Result++ = word;
            word = "";
            flag = false;
        }
        else
        {
            if (c < 0)
            {
                flag = true;
                assert(word.empty());
                word += c;
            }
            else
            {
                assert(word.empty());
                word += c;
                *__Result++ = word;
                word = "";
            }
        }
    }
    if (flag)
    {
        throw std::string("string ends with a negative character.");
    }
    return __Result;
}

template <class _CharType>
inline _CharType ToLower(_CharType __Char)
{
    return ChangeCase<_CharType>(__Char, true);
}

template <class _CharType, class _ForwardIter>
inline void ToLower(_ForwardIter __Begin, _ForwardIter __End)
{
    ChangeCase<_CharType>(__Begin, __End, true);
}

template <class _CharType>
inline void ToLower(std::basic_string<_CharType>& __String)
{
    ChangeCase<_CharType>(__String.begin(), __String.end(), true);
}

template <class _CharType>
inline _CharType ToUpper(_CharType __Char)
{
    return ChangeCase<_CharType>(__Char, false);
}

template <class _CharType, class _ForwardIter>
inline void ToUpper(_ForwardIter __Begin, _ForwardIter __End)
{
    ChangeCase<_CharType>(__Begin, __End, false);
}

template <class _CharType>
inline void ToUpper(std::basic_string<_CharType>& __String)
{
    ChangeCase<_CharType>(__String.begin(), __String.end(), false);
}

template <class _CharType>
inline std::basic_string<_CharType>& TrimLeft(std::basic_string<_CharType>& __String, const std::basic_string<_CharType>& __Trim)
{
    if (!__String.empty())
    {
        size_type pos = __String.find_first_not_of(__Trim, 0);
        if (pos == std::basic_string<_CharType>::npos)
        {
            pos = __String.length();
        }
        __String.erase(0, pos);
    }
    return __String;
}

template <class _CharType>
inline std::basic_string<_CharType>& TrimRight(std::basic_string<_CharType>& __String, const std::basic_string<_CharType>& __Trim)
{
    if (!__String.empty())
    {
        size_type pos = __String.find_last_not_of(__Trim, __String.length());
        if (pos != std::basic_string<_CharType>::npos)
        {
            __String.erase(pos + 1, __String.length() - pos);
        }
        else
        {
            __String.erase(0, __String.length());
        }
    }
    return __String;
}

template <class _CharType>
inline std::basic_string<_CharType>& Trim(std::basic_string<_CharType>& __String, const std::basic_string<_CharType>& __Trim)
{
    TrimLeft(__String, __Trim);
    TrimRight(__String, __Trim);
    return __String;
}

template <class _CharType>
inline std::basic_string<_CharType> XMLContent(const std::basic_string<_CharType>& __String, const std::basic_string<_CharType>& __Tag) throw (std::basic_string<_CharType>)
{
    typedef _CharType char_type;
    typedef std::basic_string<char_type> string_type;
    string_type start_tag = Widen<char_type>("<") + __Tag;
    string_type end_tag = Widen<char_type>("</") + __Tag + Widen<char_type>(">");
    //  start pos
    if (__String.find(start_tag) != 0)
    {
        throw string_type(Widen<char_type>("start_tag \"") + __Tag + Widen<char_type>("\" is not in the beginning."));
    }
    size_type start_pos = __String.find(Widen<char_type>(">"), 0);
    if (start_pos == string_type::npos)
    {
        throw string_type(Widen<char_type>("can not find \'>\' for start_tag \"") + __Tag + Widen<char_type>("\"."));
    }
    ++start_pos;
    //  end pos
    size_type end_pos = __String.find(end_tag, start_pos);
    if (end_pos == string_type::npos)
    {
        throw string_type(Widen<char_type>("can not find end_tag \"") + __Tag + Widen<char_type>("\""));
    }
    //  content
    return __String.substr(start_pos, end_pos - start_pos);
}

template <class _CharType>
inline std::basic_string<_CharType> XMLAttribute(const std::basic_string<_CharType>& __String, const std::basic_string<_CharType>& __Tag, const std::basic_string<_CharType>& __Attribute) throw (std::basic_string<_CharType>)
{
    typedef _CharType char_type;
    typedef std::basic_string<char_type> string_type;
    string_type start_tag = Widen<char_type>("<") + __Tag;
    string_type id_tag = __Attribute + Widen<char_type>("=");
    //  start pos
    if (__String.find(start_tag) != 0)
    {
        throw string_type(Widen<char_type>("start_tag \"") + __Tag + Widen<char_type>("\" is not in the beginning."));
    }
    size_type end_pos = __String.find(Widen<char_type>(">"), 0);
    if (end_pos == string_type::npos)
    {
        throw string_type(Widen<char_type>("can not find \'>\' for start_tag \"") + __Tag + Widen<char_type>("\"."));
    }
    //  id pos
    size_type attribute_start_pos = __String.find(id_tag, start_tag.length());
    if (attribute_start_pos == string_type::npos || attribute_start_pos > end_pos)
    {
        throw string_type(Widen<char_type>("can not find attribute \"") + __Attribute + Widen<char_type>("\"."));
    }
    attribute_start_pos += id_tag.length();
    bool quote = false;
    if (__String[attribute_start_pos] == Widen<char_type>('\"'))
    {
        quote = true;
        ++attribute_start_pos;
    }
    size_type attribute_end_pos;
    if (quote)
    {
        attribute_end_pos = __String.find_first_of(Widen<char_type>("\">"), attribute_start_pos);
    }
    else
    {
        attribute_end_pos = __String.find_first_of(Widen<char_type>(" >"), attribute_start_pos);
    }
    if (attribute_end_pos == string_type::npos || attribute_end_pos > end_pos)
    {
        throw string_type(Widen<char_type>("can not find \'\"\' for attribute \"") + __Attribute + Widen<char_type>("\"."));
    }
    if (quote)
    {
        if (__String[attribute_end_pos] != Widen<char_type>('\"'))
        {
            throw string_type(Widen<char_type>("missing right quote for attribute \"") + __Attribute + Widen<char_type>("\"."));
        }
    }
    else
    {
        if (__String[attribute_end_pos] == Widen<char_type>('\"'))
        {
            throw string_type(Widen<char_type>("missing left quote do not match for attribute \"") + __Attribute + Widen<char_type>("\"."));
        }
    }
    return __String.substr(attribute_start_pos, attribute_end_pos - attribute_start_pos);
}

//    /** @brief ɾ���ַ��������е��ڱ�� @a b �� @a e �е��ַ�, ������������Ǳ���.
//     *
//     *  @param[in]  s ת��ǰ���ַ���.
//     *  @param[in]  b ��ʼ����ַ���.
//     *  @param[in]  e ��������ַ���.
//     *  @param[out] s ת������ַ���.
//     *  @return ���� @a s ������.
//     *  @note ������ֱ��δƥ������, �������淽������ƥ��.   @n
//     *        ��: @a start = "(", @a __End = ")"ʱ,                 @n
//     *        "a(bc)d"    ->  "ad"                                @n
//     *        "a(b(c)d)e" ->  "ad)e"                              @n
//     *        "a(b(c)d"   ->  "ad"                                @n
//     *        "a(b)c)d"   ->  "ac)d"                              @n
//     *        "ab(cd"     ->  "ab(cd"                             @n
//     *        "ab)cd"     ->  "ab)cd"                             @n
//     *        "a)bc(d"    ->  "a)bc(d" 
//     */
//    inline std::string& EraseBetween(std::string& s, const std::string& b, const std::string& e)
//    {
//        assert(0);
//        size_type pos, prevpos;
//        bool flag = false;
//        
//        prevpos = 0;
//        while (true)
//        {
//            if (flag)
//            {
//                pos = s.find(e, prevpos);
//                if (pos == std::string::npos)
//                {
//                    break;
//                }
//                pos += e.length();
//                s.erase(prevpos, pos - prevpos);
//                flag = false;
//            }
//            else
//            {
//                pos = s.find(b, prevpos);
//                if (pos == std::string::npos)
//                {
//                    break;
//                }
//                prevpos = pos;
//                flag = true;
//            }
//        }
//        return s;
//    }


};  //  namespace StringHelper

#endif

